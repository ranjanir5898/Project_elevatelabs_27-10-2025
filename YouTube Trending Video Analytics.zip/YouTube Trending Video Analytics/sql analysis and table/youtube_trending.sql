CREATE DATABASE youtube_trending;
-- 1️⃣ Drop table if it already exists
DROP TABLE IF EXISTS trending_videos;

-- 2️⃣ Create table matching your CSV columns exactly
CREATE TABLE trending_videos (
    video_id TEXT,
    title TEXT,
    channel TEXT,
    publishedat TIMESTAMP NULL,
    views NUMERIC,
    likes NUMERIC,
    comments NUMERIC,
    region TEXT,
    title_sentiment TEXT
);

-- 3️⃣ Import your CSV file (⚠️ change the path below)
COPY trending_videos
FROM 'E:\Elevate Labs Internship\Project Phase\YouTube Trending Video Analytics\cleaned_youtube_trending.csv'
DELIMITER ','
CSV HEADER;

SELECT COUNT(*) FROM trending_videos;
SELECT * FROM trending_videos LIMIT 10;

-- Top 10 Most Viewed Channels
SELECT 
    channel,
    ROUND(AVG(views), 0) AS avg_views,
    SUM(views) AS total_views,
    COUNT(video_id) AS total_videos
FROM trending_videos
GROUP BY channel
ORDER BY total_views DESC
LIMIT 10;

--Average Likes per Region
SELECT 
    region,
    ROUND(AVG(likes), 0) AS avg_likes,
    ROUND(AVG(views), 0) AS avg_views,
    ROUND(AVG(comments), 0) AS avg_comments
FROM trending_videos
GROUP BY region
ORDER BY avg_likes DESC;

--Most Engaging Videos (High Like-to-View Ratio)
SELECT 
    title,
    channel,
    region,
    ROUND((likes / views) * 100, 2) AS like_ratio_percent,
    views,
    likes
FROM trending_videos
WHERE views > 0
ORDER BY like_ratio_percent DESC
LIMIT 10;

-- Sentiment vs. Views
SELECT 
    title_sentiment,
    ROUND(AVG(views), 0) AS avg_views,
    ROUND(AVG(likes), 0) AS avg_likes,
    COUNT(video_id) AS video_count
FROM trending_videos
GROUP BY title_sentiment
ORDER BY avg_views DESC;

-- Publishing Trends Over Time
SELECT 
    DATE(publishedat) AS publish_date,
    COUNT(video_id) AS total_videos,
    SUM(views) AS total_views
FROM trending_videos
GROUP BY publish_date
ORDER BY publish_date;

-- Top Channels by Average Likes per Region
SELECT 
    region,
    channel,
    ROUND(AVG(likes), 0) AS avg_likes
FROM trending_videos
GROUP BY region, channel
ORDER BY region, avg_likes DESC;

-- Identify Underperforming Videos (Low Engagement)
SELECT 
    title,
    channel,
    region,
    views,
    likes,
    comments,
    ROUND((likes / views) * 100, 2) AS like_ratio_percent
FROM trending_videos
WHERE views > 0 AND (likes / views) < 0.01
ORDER BY like_ratio_percent ASC
LIMIT 10;
